# Mutual Funds Tracker
An application to track Indian mutual funds traded on NSE.

Download the extension [here](https://chrome.google.com/webstore/detail/mutual-funds-tracker/dbkaienfbonmbigpfeacbpceheecncma)

Mobile client is coming soon ...
