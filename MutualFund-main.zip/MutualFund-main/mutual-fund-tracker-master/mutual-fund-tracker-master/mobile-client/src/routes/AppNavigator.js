import React, { Component } from 'react';
import MyNavigator from './Navigator';

export default class AppNavigator extends Component {

    render() {
        return <MyNavigator />;
    }
}