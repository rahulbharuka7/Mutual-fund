import FundDetailsScreen from './FundDetailsScreen';

export {
    FundDetailsScreen
};