import ManageFundsScreen from './ManageFundsScreen';

export {
    ManageFundsScreen
};